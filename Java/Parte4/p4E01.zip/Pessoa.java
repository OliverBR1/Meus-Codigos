package P4E01;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Pessoa {

    protected String nome;
    protected String cpf;
    protected Date dataNascimento;
    private double custoCopia = 0.10;

    Pessoa(String nome, String cpf, Date data){
        this.nome = nome;
        this.cpf = cpf;
        this.dataNascimento = data;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public double tirarCopia (double qtdCopia){
        double total = 0;
        total = custoCopia * qtdCopia;
        return total;
    }
}
