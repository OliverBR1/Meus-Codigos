package P4E01;

import java.time.LocalDate;
import java.util.Date;

public class SaidaPessoa {

    public static void main(String[] args) {
        Date n = new Date(2007-07-23);

        Funcionario f1 = new Funcionario("João", "333", new Date(1990-03-23),
            2559,new Date(2010-10-10), "Analista");

        Professor p1 = new Professor("José", "444", new Date(1980-07-29), 1559,
                "Matemática");

        Aluno a1 = new Aluno("Luiz", "666", new Date(2010-01-30),"A78910");

        f1.getFuncionarioFicha();
        p1.getProfessorFicha();
        a1.getAlunoFicha();

        System.out.println("Qtd cópias do aluno: " + f1.tirarCopia(50));




    }

}
