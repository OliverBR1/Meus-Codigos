package P4E01;

import java.util.Date;

public class Funcionario extends Pessoa{

    private double salario;
    private Date dataAdmissao;
    private String cargo;

    Funcionario(String nome, String cpf, Date dataNascimento,
                double salario, Date dataAdmissao, String cargo){
        super(nome, cpf, dataNascimento);
        this.salario = salario;
        this.dataAdmissao = dataAdmissao;
        this.cargo = cargo;
    }

    public void getFuncionarioFicha(){
        System.out.println(
                "Nome.........: " + nome +
                "\nCPF.........: " + cpf +
                "\nNascimento..: " + dataNascimento +
                "\nAdmissão....: " + dataAdmissao +
                "\nCargo.......: " + cargo);
    }

}
