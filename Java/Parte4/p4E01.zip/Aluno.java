package P4E01;

import java.util.Date;

public class Aluno extends Pessoa{

    private String matricula;
    private double custoCopia = 0.07;

    Aluno(String nome, String cpf, Date dataNascimento,
          String matricula){
        super(nome, cpf, dataNascimento);
        this.matricula = matricula;
    }
    public void getAlunoFicha(){
        System.out.println(
                "Nome.........: " + nome +
                "\nCPF.........: " + cpf +
                "\nNascimento..: " + dataNascimento +
                "\nMatricula...: " + matricula);
    }

    @Override
    public double tirarCopia(double qtdCopia) {
        return custoCopia * qtdCopia;
    }
}
