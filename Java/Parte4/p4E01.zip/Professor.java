package P4E01;

import java.util.Date;

public class Professor extends Pessoa{

    private double salario;
    private String disciplina;

    Professor(String nome, String cpf, Date dataNascimento,
              double salario, String disciplina){
        super(nome, cpf, dataNascimento);
        this.salario = salario;
        this.disciplina = disciplina;
    }

    public void getProfessorFicha(){
        System.out.println(
                "Nome.........: " + nome +
                "\nCPF.........: " + cpf +
                "\nNascimento..: " + dataNascimento +
                "\nSalario.....: " + salario +
                "\nDisciplina..: " + disciplina);
    }

}
