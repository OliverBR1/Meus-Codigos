package P4E02;

public class Funcionario {
    protected String nome;
    protected String rg;
    protected double salarioMensal;

    Funcionario(String nome, String rg, double salarioMensal){
        this.nome = nome;
        this.rg = rg;
        this.salarioMensal = salarioMensal;
    }

    Funcionario(){

    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public void setSalarioMensal(double salarioMensal) {
        this.salarioMensal = salarioMensal;
    }

    public String getNome() {
        return nome;
    }

    public String getRg() {
        return rg;
    }

    public double getSalarioMensal() {
        return salarioMensal;
    }

    public final double pagamento(){
        return salarioMensal * 0.85;
    }

    public double aumento(double aumento){
        return salarioMensal = salarioMensal + aumento;
    }

}
