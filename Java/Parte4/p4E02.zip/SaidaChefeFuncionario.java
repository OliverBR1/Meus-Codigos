package P4E02;

import java.util.Scanner;

public class SaidaChefeFuncionario {

    public static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        Chefe c1 = new Chefe("João", "2555566", 10000, 1000, 1500, 2500);
        System.out.println(c1.salarioMensal);
        c1.aumento(3000);
        System.out.println("Salario com aumento: " + c1.salarioMensal);
        System.out.println("Pagamento líquido: " + c1.pagamento());
        System.out.println("Pagamento do salario e gastos extras: " + c1.pagamentoGastosExtras());



    }

//    public static void criarChefe(){
//
//        Chefe c1 = new Chefe();
//        System.out.println("##### CADASTRO DO CHEFE #####");
//        System.out.println("Nome..............: ");
//        c1.nome = entrada.nextLine();
//        System.out.println("RG................: ");
//        c1.rg = entrada.nextLine();
//        System.out.println("Salário...........: ");
//        c1.salarioMensal = entrada.nextDouble();
//        System.out.println("Contas............: ");
//        c1.contas = entrada.nextDouble();
//        System.out.println("Gastos extras.....: ");
//        c1.gastosExtras = entrada.nextDouble();
//        System.out.println("Adicional chefia..: ");
//        c1.adicionalChefia = entrada.nextDouble();
//
//    }

}
