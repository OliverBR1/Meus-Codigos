package p4.p4E03;

/**
 * BRQ Entry Point - Grande Porte
 * @Author: Grupo 6: Bruno Oliveira, Paula Buscácio, Suleiman Divério, Valter Neto
 * */

public class Veiculo {

    private int velocidade;
    private int velocidadeMax;

    public Veiculo(int velocidade, int velocidadeMax) {
        this.velocidade = velocidade;
        this.velocidadeMax = velocidadeMax;
    }

    public Veiculo() {}

    public int getVelocidade() {
        return velocidade;
    }

    public int getVelocidadeMax() {
        return velocidadeMax;
    }

    public void acelera(int incremento) throws Exception {
        if(velocidade + incremento > velocidadeMax) {
            //exceção
            throw new Exception("A velocidade não pode ser maior que o máximo permitido que é de: " + velocidadeMax + "km/h!!!");
        } else {
            velocidade += incremento;
        }
    }

    public void desacelera(int decremento) throws Exception {
        if(velocidade - decremento < 0) {
            //exceção
            throw new Exception("A velocidade não pode ser menor que zero!!!");
        } else {
            velocidade -= decremento;
        }
    }
}
