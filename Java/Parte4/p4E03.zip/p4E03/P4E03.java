package p4.p4E03;

/**
 * BRQ Entry Point - Grande Porte
 * @Author: Grupo 6: Bruno Oliveira, Paula Buscácio, Suleiman Divério, Valter Neto
 * */

public class P4E03 {
    public static void main(String[] args) throws Exception {

        Veiculo veiculo = new Veiculo(70, 100);

        //descomentar para testar a exceção da velocidade acima da máxima
       // veiculo.acelera(40);

        veiculo.desacelera(71);

    }
}
