package p4.p4PRF;

/**
 * BRQ Entry Point - Grande Porte
 * @Author: Grupo 6: Bruno Oliveira, Paula Buscácio, Suleiman Divério, Valter Neto
 * */

public class NavioDeGuerra extends Navio{

    protected double blindagem;
    protected double ataque;

    public NavioDeGuerra(int numTripulantes, String nome, double blindagem, double ataque) {
        super(numTripulantes, nome);
        this.blindagem = blindagem;
        this.ataque = ataque;
    }

    public NavioDeGuerra() {}

    public double getBlindagem() {
        return blindagem;
    }

    public void setBlindagem(double blindagem) {
        this.blindagem = blindagem;
    }

    public double getAtaque() {
        return ataque;
    }

    public void setAtaque(double ataque) {
        this.ataque = ataque;
    }

    public void exibirArmas() {
        super.exibirInfoGeral();
        System.out.print(" **** Blindagem: " + blindagem + " **** ");
        poderDeFogo();
    }

    public void poderDeFogo() {
        System.out.println("Poder de fogo: " + ataque);
    }
}
