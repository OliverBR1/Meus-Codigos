package p4.p4PRF;

/**
 * BRQ Entry Point - Grande Porte
 * @Author: Grupo 6: Bruno Oliveira, Paula Buscácio, Suleiman Divério, Valter Neto
 * */

public class NavioMercante extends Navio {

    private double capacidadeCarga;
    private double carga;

    public NavioMercante(int numTripulantes, String nome, double capacidadeCarga, double carga) {
        super(numTripulantes, nome);
        this.capacidadeCarga = capacidadeCarga;
        this.carga = carga;
    }

    public NavioMercante(double capacidadeCarga, double carga) {
        this.capacidadeCarga = capacidadeCarga;
        this.carga = carga;
    }

    public NavioMercante() {}

    public double getCapacidadeCarga() {
        return capacidadeCarga;
    }

    public void setCapacidadeCarga(double capacidadeCarga) {
        this.capacidadeCarga = capacidadeCarga;
    }

    public double getCarga() {
        return carga;
    }

    public void setCarga(double carga) {
        this.carga = carga;
    }

    public void carregamento(int p1) {
        carga = carga + p1;
        if(carga > capacidadeCarga) {
            carga = capacidadeCarga;
        }
        super.exibirInfoGeral();
        System.out.println(" **** Volume ocupado: " + carga / capacidadeCarga);
    }

}
