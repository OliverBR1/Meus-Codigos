package p4.p4PRF;

/**
 * BRQ Entry Point - Grande Porte
 * @Author: Grupo 6: Bruno Oliveira, Paula Buscácio, Suleiman Divério, Valter Neto
 * */

public class Cruzador extends NavioDeGuerra {

    protected int numCanhoes;

    public Cruzador(int numTripulantes, String nome, double blindagem, double ataque, int numCanhoes) {
        super(numTripulantes, nome, blindagem, ataque);
        this.numCanhoes = numCanhoes;
    }

    public Cruzador(int numCanhoes) {
        this.numCanhoes = numCanhoes;
    }

    public Cruzador() {}

    public int getNumCanhoes() {
        return numCanhoes;
    }

    public void setNumCanhoes(int numCanhoes) {
        this.numCanhoes = numCanhoes;
    }

    public void poderDeFogo() {
        System.out.println("Poder de fogo: " + ataque * Math.sqrt(numCanhoes));
    }
}
