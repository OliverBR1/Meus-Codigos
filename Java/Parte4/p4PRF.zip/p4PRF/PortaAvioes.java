package p4.p4PRF;

public class PortaAvioes extends  NavioDeGuerra {

    protected int numAvioes;

    public PortaAvioes(int numTripulantes, String nome, double blindagem, double ataque, int numAvioes) {
        super(numTripulantes, nome, blindagem, ataque);
        this.numAvioes = numAvioes;
    }

    public PortaAvioes(int numAvioes) {
        this.numAvioes = numAvioes;
    }

    public PortaAvioes() {}

    public int getNumAvioes() {
        return numAvioes;
    }

    public void setNumAvioes(int numAvioes) {
        this.numAvioes = numAvioes;
    }

    public void poderDeFogo() {
        System.out.println("Poder de fogo: " + ataque * Math.pow(numAvioes,2));
    }
}
